#
# Cookbook:: build_cookbook
# Recipe:: functional
#
# Copyright:: 2019, The Authors, All Rights Reserved.
include_recipe 'delivery-truck::functional'
